<?php
require_once ('connection.php');
date_default_timezone_set("Asia/Calcutta");

$urname = $_POST['name'];
$urphone = $_POST['phone'];
$urtype = $_POST['type'];
$uremail = $_POST['email'];
session_start();
$usrid = "tn" . date("Y") . "mtc_";
$sql1 = "select * from users where id=(SELECT max(id) from users) ";
$result = mysqli_query($conn, $sql1);



 


if ($result != false)
{
    $flag = 1;
    while ($row = mysqli_fetch_array($result))
    {
        $tempid = $row["id"];
        $usrid .= (string)($row["id"] + 1);
    }
}

$sql1 = "select * from users";
$result = mysqli_query($conn, $sql1);

if ($result != false)
{

    while ($row = mysqli_fetch_array($result))
    {
        $tmpph = $row["Phone"];

        if ($tmpph == $urphone)
        {
            $flag = 0;
        }
    }
}
if ($flag)
{
    if ($urtype == "day")
    {
        $date = (String)date('d-m-Y');

        $expiry = date('d-m-Y', strtotime($date . ' + 1 days'));
        $sql = "INSERT INTO users(mtcid,Name,Expiry,Phone,Fare,Type,Email) VALUES('$usrid','$urname','$expiry','$urphone','50','$urtype','$uremail')";
        $res = mysqli_query($conn, $sql);
    }

    elseif ($urtype == "month")
    {
        $date = (String)date('d-m-Y');

        $expiry = date('d-m-Y', strtotime($date . ' + 30 days'));
        $sql = "INSERT INTO users(mtcid,Name,Expiry,Phone,Fare,Type,Email) VALUES('$usrid','$urname','$expiry','$urphone','1000','$urtype','$uremail')";
        $res = mysqli_query($conn, $sql);
    }


    $date = date("Y-m-d");
    $time = date("h:i:sa");
    if($pay_his_d == NULL)
    {
        $pay_his_d = $date;
        $sql1 = "UPDATE users SET Payment_his_date = '$pay_his_d' WHERE Phone='$phone' and Name = '$name'";
        //echo "$temp";
        mysqli_query($conn, $sql1);
    }
    else
    {
        //$name = $pay_his_d;
        $array = explode(",", $pay_his_d);
        array_push($array, $date);
        $temp = implode(',',$array);
        $sql1 = "UPDATE users SET Payment_his_date = '$temp' WHERE Phone='$phone' and Name = '$name'";
        //echo "$temp";
        mysqli_query($conn, $sql1);
    # code...
    }
    if($pay_his_t == NULL)
    {
        $pay_his_t = $time;
        $sql1 = "UPDATE users SET Payment_his_time= '$pay_his_t' WHERE Phone='$phone' and Name = '$name'";
        //echo "$temp";
        mysqli_query($conn, $sql1);
    }
    else
    {
        //$name = $pay_his_d;
        $array = explode(",", $pay_his_t);
        array_push($array, $time);
        $temp = implode(',',$array);
        $sql1 = "UPDATE users SET Payment_his_time = '$temp' WHERE Phone='$phone' and Name = '$name'";
        //echo "$temp";
        mysqli_query($conn, $sql1);
    # code...
    }

    
$ntable = "CREATE TABLE `$usrid` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  
  `Date1` varchar(100) NOT NULL,
  `Time1` varchar(500) NOT NULL,
  `From1`  varchar(500) NOT NULL,
  `To1`  varchar(500) NOT NULL,
  PRIMARY KEY (id)
)";

    if (!mysqli_query($conn, $ntable))
    {
        die('Sorry for inconvineince' . mysqli_error($conn));
    }
    else
    {
        setcookie('Phone', $urphone, time() + (86400 * 3000));
    setcookie('Name', $urname, time() + (86400 * 3000));
        header("Location:payment.php");
        exit();
    }

}
else
{
    echo "USER EXITS";
}

?>
