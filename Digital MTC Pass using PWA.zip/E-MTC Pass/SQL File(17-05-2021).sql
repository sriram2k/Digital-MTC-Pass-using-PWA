-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 17, 2021 at 05:14 AM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mtc`
--

-- --------------------------------------------------------

--
-- Table structure for table `routes`
--

CREATE TABLE `routes` (
  `id` int(11) NOT NULL,
  `bus_no` varchar(100) NOT NULL,
  `bus_route` varchar(10000) NOT NULL,
  `real_route` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `routes`
--

INSERT INTO `routes` (`id`, `bus_no`, `bus_route`, `real_route`) VALUES
(1, '70C', 'KOYMABEDUMARKET,KOYAMBEDUPS,MMDACOLONYRDJN,JNOFIIIAND1STAVE,JAFFARKHANPET,CIPET,STTHOMASMOUNTPO,MENAMABAKKAMOLDAIRPORT,THIRUSOOLAMNATIONALAIRP,PALLAVARAM,CHROMPET,TBSANATORIUM,TAMBARAM', 'KOYMABEDU MARKET, KOYAMBEDU P.S, M.M.D.A.COLONY RD.JN., JN OF III AND 1ST AVE, JAFFARKHAN PET, CIPET, ST THOMAS MOUNT PO, MENAMABAKKAM OLD AIRPORT, THIRUSOOLAM NATIONAL AIRP, PALLAVARAM, CHROMPET, T.B.SANATORIUM, TAMBARAM'),
(2, '62', 'REDHILLS,AAYURVEDAASHRAMAM,KAVANGARAI,SCREWFACTORY,SURAPEDU,KALLIKUPPAM,PUDUR,AMBOT,THIRUMULLAIVOAYL,POLYTECHNIC,AVADI', 'RED HILLS, AAYURVEDA ASHRAMAM, KAVANGARAI, SCREW FACTORY, SURAPEDU, KALLIKUPPAM, PUDUR, AMB OT, THIRUMULLAIVOAYL, POLYTECHNIC, AVADI'),
(3, 'S147C', 'AMBOT,DUNLOP,AMBATHURESTATE,MOGAIPAIRROADJN,THIRUMANGALAM,ANNANAGARCIRCLE,HOTELARUN,NUNGAMBAKKAMRS,STERLINGROAD,UTHAMARGANDHISALAICORP,VIDYODAYA,PONDYBAZAAR,TNAGAR', 'AMB OT, DUNLOP, AMBATHUR ESTATE, MOGAIPAIR ROAD JN., THIRUMANGALAM, ANNA NAGAR CIRCLE, HOTEL ARUN, NUNGAMBAKKAM R.S, STERLING ROAD, UTHAMAR GANDHISALAI (CORP, VIDYODAYA, PONDY BAZAAR, T.NAGAR'),
(4, 'M52ET', 'POZHICHALUR,PAMMAL,PALLAVARAM,CHROMPET,TBSANATORIUM,TAMBARAM,IRUMBULIYUR,PERUNGULATHUR,VANDALOOR,VANDALOORZOO,OORAPAKKAMSCHOOL,PALAKKACOMPANY,GUDUVANCHERY', 'POZHICHALUR, PAMMAL, PALLAVARAM, CHROMPET, T.B.SANATORIUM, TAMBARAM, IRUMBULIYUR, PERUNGULATHUR, VANDALOOR, VANDALOOR ZOO, OORAPAKKAM SCHOOL, PALAKKA COMPANY, GUDUVANCHERY'),
(5, '248ET', 'VNAGAR,P1POLICESTATION,DASAMAHAN,AYNAVARAM,KAMABARARANGAM,NATHAMUNITALKIES,LUCASTVS,AMBATHURESTATE,DUNLOP,AMBOT,ORAGADAMOT,ORAGADAM', 'V. NAGAR, P1.POLICE STATION, DASAMAHAN, AYNAVARAM, KAMABAR ARANGAM, NATHAMUNI TALKIES, LUCAS TVS, AMBATHUR ESTATE, DUNLOP, AMB OT, ORAGADAM O.T., ORAGADAM');

-- --------------------------------------------------------

--
-- Table structure for table `tn2021mtc_2`
--

CREATE TABLE `tn2021mtc_2` (
  `id` int(11) NOT NULL,
  `Date1` varchar(100) NOT NULL,
  `Time1` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tn2021mtc_2`
--

INSERT INTO `tn2021mtc_2` (`id`, `Date1`, `Time1`) VALUES
(1, '23rd - 03 - 2021', '01:56 PM'),
(2, '10th - 04 - 2021', '09:06 AM'),
(3, '10th - 04 - 2021', '02:03 PM'),
(4, '10th - 04 - 2021', '02:04 PM');

-- --------------------------------------------------------

--
-- Table structure for table `tn2021mtc_64`
--

CREATE TABLE `tn2021mtc_64` (
  `id` int(11) NOT NULL,
  `Date1` varchar(100) NOT NULL,
  `Time1` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tn2021mtc_65`
--

CREATE TABLE `tn2021mtc_65` (
  `id` int(11) NOT NULL,
  `Date1` varchar(100) NOT NULL,
  `Time1` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tn2021mtc_65`
--

INSERT INTO `tn2021mtc_65` (`id`, `Date1`, `Time1`) VALUES
(1, '24th - 03 - 2021', '11:21 AM'),
(2, '24th - 03 - 2021', '11:22 AM'),
(3, '24th - 03 - 2021', '11:25 AM'),
(4, '24th - 03 - 2021', '02:22 PM'),
(5, '24th - 03 - 2021', '02:24 PM'),
(6, '24th - 03 - 2021', '02:25 PM'),
(7, '24th - 03 - 2021', '02:25 PM'),
(8, '24th - 03 - 2021', '02:26 PM'),
(9, '24th - 03 - 2021', '02:27 PM'),
(10, '24th - 03 - 2021', '02:27 PM'),
(11, '24th - 03 - 2021', '02:27 PM'),
(12, '24th - 03 - 2021', '02:30 PM'),
(13, '24th - 03 - 2021', '02:31 PM'),
(14, '24th - 03 - 2021', '02:31 PM'),
(15, '24th - 03 - 2021', '07:51 PM');

-- --------------------------------------------------------

--
-- Table structure for table `tn2021mtc_66`
--

CREATE TABLE `tn2021mtc_66` (
  `id` int(11) NOT NULL,
  `Date1` varchar(100) NOT NULL,
  `Time1` varchar(500) NOT NULL,
  `From1` varchar(500) NOT NULL,
  `To1` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tn2021mtc_66`
--

INSERT INTO `tn2021mtc_66` (`id`, `Date1`, `Time1`, `From1`, `To1`) VALUES
(1, '24th - 03 - 2021', '11:42 AM', '', ''),
(2, '24th - 03 - 2021', '02:21 PM', '', ''),
(3, '27th - 03 - 2021', '08:26 PM', 'REDHILLS', 'KALLIKUPPAM'),
(4, '27th - 03 - 2021', '08:26 PM', 'REDHILLS', 'KALLIKUPPAM'),
(5, '27th - 03 - 2021', '08:33 PM', 'KAVANGARAI', 'SCREWFACTORY'),
(6, '27th - 03 - 2021', '08:34 PM', 'SURAPEDU', 'AMBOT'),
(7, '8th - 04 - 2021', '07:44 PM', 'KALLIKUPPAM', 'PUDUR'),
(8, '8th - 04 - 2021', '07:45 PM', 'SURAPEDU', 'THIRUMULLAIVOAYL'),
(9, '10th - 04 - 2021', '09:02 AM', 'CHROMPET', 'VANDALOOR'),
(10, '10th - 04 - 2021', '09:11 AM', 'PAMMAL', 'OORAPAKKAMSCHOOL');

-- --------------------------------------------------------

--
-- Table structure for table `tn2021mtc_70`
--

CREATE TABLE `tn2021mtc_70` (
  `id` int(11) NOT NULL,
  `Date1` varchar(100) NOT NULL,
  `Time1` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tn2021mtc_70`
--

INSERT INTO `tn2021mtc_70` (`id`, `Date1`, `Time1`) VALUES
(1, '26th - 04 - 2021', '12:22 PM'),
(2, '26th - 04 - 2021', '12:23 PM'),
(3, '26th - 04 - 2021', '12:24 PM'),
(4, '26th - 04 - 2021', '12:24 PM');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `mtcid` varchar(200) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Expiry` text NOT NULL,
  `Phone` varchar(100) NOT NULL,
  `Fare` int(11) NOT NULL,
  `Due_Paid` varchar(20) NOT NULL,
  `Due_crossed` int(11) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Coll_Comp` varchar(100) NOT NULL,
  `img` varchar(1000) NOT NULL,
  `aadhaar` varchar(1000) NOT NULL,
  `proof` varchar(1000) NOT NULL,
  `Type` varchar(1000) NOT NULL,
  `Payment_his_time` longtext NOT NULL,
  `Payment_his_date` varchar(1000) NOT NULL,
  `From1` varchar(100) NOT NULL,
  `To1` varchar(100) NOT NULL,
  `From2` varchar(1000) NOT NULL,
  `To2` varchar(1000) NOT NULL,
  `Count` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `mtcid`, `Name`, `Expiry`, `Phone`, `Fare`, `Due_Paid`, `Due_crossed`, `Email`, `Coll_Comp`, `img`, `aadhaar`, `proof`, `Type`, `Payment_his_time`, `Payment_his_date`, `From1`, `To1`, `From2`, `To2`, `Count`) VALUES
(1, 'tn2021mtc_', 'Temp', '', '0000', 0, '', 0, '', '', '', '', '', '', '', '', 'Temp', 'Temp', '', '', 0),
(63, 'tn2021mtc_2', 'Praveen', '11-06-2021', '8825511238', 140, 'Paid', 0, 'praveen2005kumar@gmail.com', 'VEC', '-1616486125.', '-1616486125.', '-1616486125.', 'college_two_way', '', '', 'RED HILLS', 'AMB OT', 'V. NAGAR', 'KAMABAR ARANGAM', 3),
(64, 'tn2021mtc_64', 'divya', '11-05-2021', '9940579313', 280, 'Due', 1, 'divyaprakash473@gmail.com', 'VEC', '-1616504083.', '-1616504083.', '-1616504083.', 'college_one_way', '', '', 'M.M.D.A.COLONY RD.JN.', 'TAMBARAM', '', '', 0),
(65, 'tn2021mtc_65', 'Kumar', '25-03-2021', '9171831422', 0, '', 0, '', '', '', '', '', 'day', '', '', '', '', '', '', 42),
(69, 'tn2021mtc_66', 'Divya', '23-04-2021', '123', 0, '', 0, '', '', '', '', '', 'day', '', '', '', '', '', '', 12),
(89, 'tn2021mtc_70', 'surya', '11-06-2021', '8754471346', 280, 'Paid', 0, 'rapraveenkumar.sasi@gmail.com', 'VEC', 'd7a86e23a3c41f0423f8783c30c42657-1619418105.jpg', 'oie_yr3twc0wtvm8-(2)-1619418105.jpg', 'f-1619418105.f', 'college_two_way', '11:51:45am,12:25:37pm', '2021-04-26,2021-04-26', 'PALLAVARAM', 'PERUNGULATHUR', 'CHROMPET', 'TAMBARAM', 4);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `routes`
--
ALTER TABLE `routes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tn2021mtc_2`
--
ALTER TABLE `tn2021mtc_2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tn2021mtc_64`
--
ALTER TABLE `tn2021mtc_64`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tn2021mtc_65`
--
ALTER TABLE `tn2021mtc_65`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tn2021mtc_66`
--
ALTER TABLE `tn2021mtc_66`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tn2021mtc_70`
--
ALTER TABLE `tn2021mtc_70`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `routes`
--
ALTER TABLE `routes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tn2021mtc_2`
--
ALTER TABLE `tn2021mtc_2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tn2021mtc_64`
--
ALTER TABLE `tn2021mtc_64`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tn2021mtc_65`
--
ALTER TABLE `tn2021mtc_65`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tn2021mtc_66`
--
ALTER TABLE `tn2021mtc_66`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tn2021mtc_70`
--
ALTER TABLE `tn2021mtc_70`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=91;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
