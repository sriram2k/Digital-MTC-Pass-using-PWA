<?php
include 'connection.php';
$name = "";
$busno = $_GET['route'];
$from_arr = array();
$to_arr = array();
$sql = "SELECT * FROM routes WHERE bus_no= '$busno'";
$res = mysqli_query($conn , $sql);
while ($row = mysqli_fetch_assoc($res)) {
	$name = $row["real_route"];
    $from_arr = explode(",", $name);
    $to_arr = explode(",", $name);

	
} 

if (isset($_POST['submit'])) { 
 $NAME = $_POST["light1"]; 
 $EMAIL = $_POST["light2"]; 
 header("Location:addcount.php?from_tayl=".$NAME."&to_tayl=".$EMAIL);
  
 } 

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<body>
<form method="post"> 
<section class="light">

  <h1>Starting Point</h1>
<?php for ($i=0; $i < sizeof($from_arr) ; $i++) {  ?>
	
  <label>
    <input id="input" type="radio" name="light1" value="<?php echo "$from_arr[$i]"; ?>">
    <span class="design"></span>
    <span class="text"><?php echo "$from_arr[$i]"; ?></span>
  </label>
<?php } ?>

  <h1>Destination</h1>
<?php for ($i=0; $i < sizeof($to_arr) ; $i++) {  ?>
	
  <label>
    <input id="input" type="radio" name="light2" value="<?php echo "$to_arr[$i]"; ?>">
    <span class="design"></span>
    <span class="text"><?php echo "$to_arr[$i]"; ?></span>
  </label>
<?php } ?>
<input class="button" type="submit" name="submit">


</section>

</form>

<style type="text/css">
	/* body */
body {
  min-height: 100vh;

  display: flex;
  

  margin: 0;
  padding: 0;
  font-size: 12px;

  font-family: 'Segoe UI', -apple-system, BlinkMacSystemFont, sans-serif;
}


/* section */
section {
  width: 150%;
  min-height: inherit;
margin-left: 12%;
  display: flex;
 
  flex-direction: column;

  position: relative;
}

section::before,
section::after {
  content: "";
  display: block;

  border-radius: 100%;

  position: absolute;
}


.light {
  --primary: hsl(250, 100%, 44%);
  --other: hsl(0, 0%, 14%);

  background: hsl(0, 0%, 98%);
}

.dark {
  --primary: hsl(1, 100%, 68%);
  --other: hsl(0, 0%, 90%);

  background: hsl(0, 0%, 10%);
}


/* h1 */
h1 {
  color: var(--other);
  padding: 8px 4px;
  border-bottom: 2px solid var(--other);
}


/* label */
label {
  display: flex;
  justify-content: flex-start;
  align-items: center;
  flex-wrap: nowrap;

  margin: 12px 0;

  cursor: pointer;
  position: relative;
}


/* input */
#input {
  opacity: 0;
  position: absolute;
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);
  z-index: -1;
}
.button {
  background-color: #33b5e5; /* Green */
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
}

/* .design */
.design {
  width: 16px;
  height: 16px;

  border: 1px solid var(--other);
  border-radius: 100%;
  margin-right: 16px;

  position: relative;
}

.design::before,
.design::after {
  content: "";
  display: block;

  width: inherit;
  height: inherit;

  border-radius: inherit;

  position: absolute;
  transform: scale(0);
  transform-origin: center center;
}

.design:before {
  background: var(--other);
  opacity: 0;
  transition: .1s;
}

.design::after {
  background: var(--primary);
  opacity: .4;
  transition: .1s;
}


/* .text */
.text {
  color: var(--other);
  font-weight: bold;
}


/* checked state */
input:checked+.design::before {
  opacity: 1;
  transform: scale(.6);
}


/* other states */
input:hover+.design,
input:focus+.design {
  border: 1px solid var(--primary);
}

input:hover+.design:before,
input:focus+.design:before {
  background: var(--primary);
}

input:hover~.text {
  color: var(--primary);
}

input:focus+.design::after,
input:active+.design::after {
  opacity: .1;
  transform: scale(2.6);
}

.abs-site-link {
  position: fixed;
  bottom: 20px;
  left: 20px;
  color: hsla(0, 0%, 0%, .6);
  background: hsla(0, 0%, 98%, .6);
  font-size: 16px;
}

</style>
</body>
</html>