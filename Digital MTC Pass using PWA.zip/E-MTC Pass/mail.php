<?php

include 'connection.php';
date_default_timezone_set("Asia/Calcutta");
$name = $_COOKIE['Name'];
$phone = $_COOKIE['Phone'];
$sql = "SELECT * FROM users WHERE Phone='$phone' and Name = '$name'";
$res = mysqli_query($conn, $sql);
if (mysqli_num_rows($res) > 0)
{
    while ($row = mysqli_fetch_assoc($res))
    {

        $usrid = $row['mtcid'];
        $urname = $row['Name'];
        $urphone = $row['Phone'];
        $type = $row['Type'];
        $from1 = $row['From1'];
        $from2 = $row['From2'];
        $to1 = $row['To1'];
        $to2 = $row['To2'];
        $email = $row['Email'];
        $fare = $row['Fare'];
        $pay_his_d = $row['Payment_his_date'];
        $pay_his_t = $row['Payment_his_time'];

    }

}

$to_email = $email;
$subject = "payment succcessfull";
$body = "Hi ".$urname." Payment succcessfull";
$headers = "From: praveen2005kumar@gmail.com";
header("location:index.php");
/*
if (mail($to_email, $subject, $body, $headers)) {
    
} else {
    echo "Email sending failed...";
}*/
?>