<?php
date_default_timezone_set("Asia/Calcutta");
require_once ('connection.php');
session_start();


$date = date('d');
$usname = $_COOKIE['Name'];
$usphone = (String)$_COOKIE['Phone'];
$sql = "SELECT * FROM users WHERE (Phone='$usphone' and Name = '$usname')";
$res = mysqli_query($conn, $sql);
if (mysqli_num_rows($res) > 0)
{
    while ($row = mysqli_fetch_assoc($res))
    {
        $usrid = $row['mtcid'];
        $count = $row['Count'];
        $from = $row['From1'];
        $to = $row['To1'];
        $from2 = $row['From2'];
        $to2 = $row['To2'];
        $type = $row['Type'];
        $img = $row['img'];
        $due = $row['Due_Paid'];
        $due_cross = $row['Due_crossed'];
    }
}
else
{
    echo "invlaid";
}
$propic = 'propic/' . (String)$img;



?>


<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Dashboard - MTC</title>
    <link rel="icon" type="image/png" sizes="192x192" href="assets/img/icon-192x192.png">
    <link rel="icon" type="image/png" sizes="192x192" href="assets/img/icon-192x192.png">
    <link rel="icon" type="image/png" sizes="192x192" href="assets/img/icon-192x192.png">
    <link rel="icon" type="image/png" sizes="512x512" href="assets/img/icon-512x512.png">
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Anton">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome5-overrides.min.css">
</head>

<body id="page-top" class=" animate__animated animate__fadeIn animate__fast">
    <div id="wrapper">
        <nav class="navbar navbar-dark align-items-start fixed-bottom accordion bg-gradient-primary p-0">
            <div class="container-fluid d-flex flex-column p-0"><a class="navbar-brand d-flex justify-content-center align-items-center sidebar-brand m-0" href="#">
                    
                </a>
                <hr class="sidebar-divider my-0">
                <ul class="navbar-nav text-light" id="accordionSidebar">
                    
                    <li class="nav-item"><a class="nav-link" href="profile.php"><i class="fas fa-user"></i></a></li>&nbsp;&nbsp;&nbsp;
                    <li class="nav-item"><a class="nav-link" href="table.php"><i class="fas fa-table"></i></a></li>&nbsp;&nbsp;&nbsp;
                    <li class="nav-item"><a class="nav-link active" href="index.php"><i class="fas fa-tachometer-alt"></i></a></li>&nbsp;&nbsp;&nbsp;
                    <li class="nav-item"><a class="nav-link" href="paymenthistory.php"><i class="fa fa-rupee"></i></a></li>&nbsp;&nbsp;&nbsp;

                    <li class="nav-item"><a class="nav-link" href="logout.php"><i class="fas fa-sign-out-alt"></i></a></li>&nbsp;&nbsp;&nbsp;
                </ul>
                <div class="text-center d-none d-md-inline"><button class="btn rounded-circle border-0" id="sidebarToggle" type="button"></button></div>
            </div>
        </nav>
        <div class="d-flex flex-column" id="content-wrapper">
            <div id="content">
                <nav class="navbar navbar-light navbar-expand bg-white shadow mb-4 topbar static-top">
                    <div class="container-fluid">
                        <p class="text-dark" style="text-align: center;font-weight: 800;font-size: 20px;font-family: Nunito, sans-serif;font-style: normal;margin-top: 12px;margin-right: 19px;">MTC Pass</p></a>
                    </div>
                </nav>
                <div class="container-fluid">
                    <div class="d-sm-flex justify-content-between align-items-center mb-4"></div>
                    <div class="row">
                        <div class="col">
                            <h3 class="text-center text-dark mb-0">ID: <?php echo "$usrid"; ?></h3>
                        </div>
                        
                        
                        <div class="col-lg-5 col-xl-4 animate__animated animate__backInUp">
                            <div class="card shadow mb-4">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col"><a class="btn btn-light btn-lg d-flex justify-content-center btn-icon-split" href="scan.html" role="button"><span class="text-black-50 icon"><i class="fas fa-qrcode"></i></span><span class="text-dark text">Scan MTC Code</span></a></div>
                                    </div>
                                    <bR>
                                    
                                </div>
                            </div>
                        </div>  


<div class="col-md-6 col-xl-3 mb-4 animate__animated animate__backInUp">
                            <div class="card shadow border-left-success py-2">
                            
                                <div class="card-body">
                                    <div class="row align-items-center no-gutters">
                                    <div class="col">
                                    <div class="text-center text-dark font-weight-bold h5 mb-0"><?php echo $count ?></div>
                                    </div>
                                    
                                    </div>
                                </div>
                            </div>
                        </div>







  
                       

                    </div>
                </div>
            </div>
            <footer class="bg-white sticky-footer">
                <div class="row">
                    <div class="col">
                        <h4 class="text-center"><?php echo  date("h:i A"); ?></h4>
                    </div>
                </div>
                <div class="container my-auto">
                    <div class="text-center my-auto copyright"><span>Copyright © E Bus Pass 2021</span></div><br><br><br><br>
                </div>
            </footer>
        </div>
    </div>

    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.js"></script>
    <script src="assets/js/theme.js"></script>
</body>

</html>
