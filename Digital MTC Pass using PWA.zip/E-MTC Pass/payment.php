<?php
include 'connection.php';
date_default_timezone_set("Asia/Calcutta");
$name = $_COOKIE['Name'];
$phone = $_COOKIE['Phone'];
$sql = "SELECT * FROM users WHERE Phone='$phone' and Name = '$name'";
$res = mysqli_query($conn, $sql);
if (mysqli_num_rows($res) > 0)
{
    while ($row = mysqli_fetch_assoc($res))
    {

        $usrid = $row['mtcid'];
        $urname = $row['Name'];
        $urphone = $row['Phone'];
        $type = $row['Type'];
        $from1 = $row['From1'];
        $from2 = $row['From2'];
        $to1 = $row['To1'];
        $to2 = $row['To2'];
        $email = $row['Email'];
        $fare = $row['Fare'];
        $pay_his_d = $row['Payment_his_date'];
        $pay_his_t = $row['Payment_his_time'];

    }

}

    $date = date("d - m - Y");
    $time = date("h:i:sa");
    if($pay_his_d == NULL)
    {
        $pay_his_d = $date;
        $sql1 = "UPDATE users SET Payment_his_date = '$pay_his_d' WHERE Phone='$phone' and Name = '$name'";
        //echo "$temp";
        mysqli_query($conn, $sql1);
    }
    else
    {
        //$name = $pay_his_d;
        $array = explode(",", $pay_his_d);
        array_push($array, $date);
        $temp = implode(',',$array);
        $sql1 = "UPDATE users SET Payment_his_date = '$temp' WHERE Phone='$phone' and Name = '$name'";
        //echo "$temp";
        mysqli_query($conn, $sql1);
    # code...
    }
    if($pay_his_t == NULL)
    {
        $pay_his_t = $time;
        $sql1 = "UPDATE users SET Payment_his_time= '$pay_his_t' WHERE Phone='$phone' and Name = '$name'";
        //echo "$temp";
        mysqli_query($conn, $sql1);
    }
    else
    {
        //$name = $pay_his_d;
        $array = explode(",", $pay_his_t);
        array_push($array, $time);
        $temp = implode(',',$array);
        $sql1 = "UPDATE users SET Payment_his_time = '$temp' WHERE Phone='$phone' and Name = '$name'";
        //echo "$temp";
        mysqli_query($conn, $sql1);
    # code...
    }


?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Payment - MTC</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="payment.css">
  </head>
  <body>
    <div class="container py-5">
    <!-- For demo purpose -->
    <div class="row mb-4">
        <div class="col-lg-8 mx-auto text-center">
            <h1 class="display-6">Payment Gateway</h1>
        </div>
    </div> <!-- End -->
    <div class="row">
        <div class="col-lg-6 mx-auto ">
            <?php if($type == 'day'){ ?>
                            <h4 class="card-title">Fare: 50</h4>
                          <?php } else if($type == 'month'){  ?>
                            <h4 class="card-title">Fare: 1000</h4>
                        <?php }else{ ?>
                        	<h4 class="card-title">Fare: <?php echo "$fare"; ?></h4>
                        <?php } ?>



                          <p>To: MTC Bus Dept(Renewal)</p>
                          <p >Name: <?php echo $urname; ?></p>
                            <p >Phone: <?php echo $urphone; ?></p>

        </div>

        <div class="col-lg-6 mx-auto">
            <div class="card ">
                <div class="card-header">
                    <div class="bg-white shadow-sm pt-4 pl-2 pr-2 pb-2">
                        <!-- Credit card form tabs -->
                        <ul role="tablist" class="nav bg-light nav-pills rounded nav-fill mb-3">
                            <li class="nav-item"> <a data-toggle="pill" href="#credit-card" class="nav-link active "> <i class="fas fa-credit-card mr-2"></i> Credit Card </a> </li>
                            <li class="nav-item"> <a data-toggle="pill" href="#paypal" class="nav-link "> <i class="fab fa-paypal mr-2"></i> Paypal </a> </li>
                            <li class="nav-item"> <a data-toggle="pill" href="#net-banking" class="nav-link "> <i class="fas fa-mobile-alt mr-2"></i> Net Banking </a> </li>
                        </ul>
                    </div> <!-- End -->
                    <!-- Credit card form content -->
                    <div class="tab-content">
                        <!-- credit card info-->
                        <div id="credit-card" class="tab-pane fade show active pt-3">
                            <form role="form">
                                <div class="form-group"> <label for="username">
                                        <h6>Card Owner</h6>
                                    </label> <input type="text" name="username" placeholder="Card Owner Name" required class="form-control "> </div>
                                <div class="form-group"> <label for="cardNumber">
                                        <h6>Card number</h6>
                                    </label>
                                    <div class="input-group"> <input type="text" name="cardNumber" placeholder="Valid card number" class="form-control " required>
                                        <div class="input-group-append"> <span class="input-group-text text-muted"> <i class="fab fa-cc-visa mx-1"></i> <i class="fab fa-cc-mastercard mx-1"></i> <i class="fab fa-cc-amex mx-1"></i> </span> </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-8">
                                        <div class="form-group"> <label><span class="hidden-xs">
                                                    <h6>Expiration Date</h6>
                                                </span></label>
                                            <div class="input-group"> <input type="number" placeholder="MM" name="" class="form-control" required> <input type="number" placeholder="YY" name="" class="form-control" required> </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class="form-group mb-4"> <label data-toggle="tooltip" title="Three digit CV code on the back of your card">
                                                <h6>CVV <i class="fa fa-question-circle d-inline"></i></h6>
                                            </label> <input type="text" required class="form-control"> </div>
                                    </div>
                                </div>
                                <div class="card-footer"><a href="mail.php"><button type="button" class="subscribe btn btn-primary btn-block shadow-sm"> Confirm Payment </button></a>
                            </form>
                        </div>
                    </div> <!-- End -->
                    <!-- Paypal info -->
                    <div id="paypal" class="tab-pane fade pt-3">
                        <h6 class="pb-2">Select your paypal account type</h6>
                        <div class="form-group "> <label class="radio-inline"> <input type="radio" name="optradio" checked> Domestic </label> <label class="radio-inline"> <input type="radio" name="optradio" class="ml-5">International </label></div>
                        <p> <button type="button" class="btn btn-primary "><i class="fab fa-paypal mr-2"></i> Log into my Paypal</button> </p>
                        <p class="text-muted"> Note: After clicking on the button, you will be directed to a secure gateway for payment. After completing the payment process, you will be redirected back to the website to view details of your order. </p>
                    </div> <!-- End -->
                    <!-- bank transfer info -->
                    <div id="net-banking" class="tab-pane fade pt-3">
                        <div class="form-group "> <label for="Select Your Bank">
                                <h6>Select your Bank</h6>
                            </label> <select class="form-control" id="ccmonth">
                                <option value="" selected disabled>--Please select your Bank--</option>
                                <option>State Bank of India</option>
                                <option>Indian Overseas Bank</option>
                                <option>Union Bank of India</option>
                                <option>Axis Bank</option>
                                <option>City Union Bank</option>
                                <option>HDFC Bank</option>
                                <option>IDFC First Bank</option>
                                <option>Karur Vysya Bank</option>
                                <option>ICICI Bank</option>
                            </select> </div>
                        <div class="form-group">
                            <p> <button type="button" class="btn btn-primary "><i class="fas fa-mobile-alt mr-2"></i> Proceed Payment</button> </p>
                        </div>
                        <p class="text-muted">Note: After clicking on the button, you will be directed to a secure gateway for payment. After completing the payment process, you will be redirected back to the website to view details of your order. </p>
                    </div> <!-- End -->
                    <!-- End -->
                </div>
            </div>
        </div>
    </div>
    <?php
//   public function mail()
//   {

// $to_email = "praveen2005kumar@gmail.com";
// $subject = "Simple Email Test via PHP";
// $body = '<html>

// <body style="background-color:#e2e1e0;font-family: Open Sans, sans-serif;font-size:100%;font-weight:400;line-height:1.4;color:#000;">
//   <table style="max-width:670px;margin:50px auto 10px;background-color:#fff;padding:50px;-webkit-border-radius:3px;-moz-border-radius:3px;border-radius:3px;-webkit-box-shadow:0 1px 3px rgba(0,0,0,.12),0 1px 2px rgba(0,0,0,.24);-moz-box-shadow:0 1px 3px rgba(0,0,0,.12),0 1px 2px rgba(0,0,0,.24);box-shadow:0 1px 3px rgba(0,0,0,.12),0 1px 2px rgba(0,0,0,.24); border-top: solid 10px green;">
//     <thead>
//       <tr>
//         <th style="text-align:left;"><img style="max-width: 150px;" src="https://www.bachanatours.in/book/img/logo.png" alt="bachana tours"></th>
//         <th style="text-align:right;font-weight:400;">05th Apr, 2017</th>
//       </tr>
//     </thead>
//     <tbody>
//       <tr>
//         <td style="height:35px;"></td>
//       </tr>
//       <tr>
//         <td colspan="2" style="border: solid 1px #ddd; padding:10px 20px;">
//           <p style="font-size:14px;margin:0 0 6px 0;"><span style="font-weight:bold;display:inline-block;min-width:150px">Order status</span><b style="color:green;font-weight:normal;margin:0">Success</b></p>
//           <p style="font-size:14px;margin:0 0 6px 0;"><span style="font-weight:bold;display:inline-block;min-width:146px">Transaction ID</span> abcd1234567890</p>
//           <p style="font-size:14px;margin:0 0 0 0;"><span style="font-weight:bold;display:inline-block;min-width:146px">Order amount</span> Rs. 6000.00</p>
//         </td>
//       </tr>
//       <tr>
//         <td style="height:35px;"></td>
//       </tr>
//       <tr>
//         <td style="width:50%;padding:20px;vertical-align:top">
//           <p style="margin:0 0 10px 0;padding:0;font-size:14px;"><span style="display:block;font-weight:bold;font-size:13px">Name</span> Palash Basak</p>
//           <p style="margin:0 0 10px 0;padding:0;font-size:14px;"><span style="display:block;font-weight:bold;font-size:13px;">Email</span> palash@gmail.com</p>
//           <p style="margin:0 0 10px 0;padding:0;font-size:14px;"><span style="display:block;font-weight:bold;font-size:13px;">Phone</span> +91-1234567890</p>
//           <p style="margin:0 0 10px 0;padding:0;font-size:14px;"><span style="display:block;font-weight:bold;font-size:13px;">ID No.</span> 2556-1259-9842</p>
//         </td>
//         <td style="width:50%;padding:20px;vertical-align:top">
//           <p style="margin:0 0 10px 0;padding:0;font-size:14px;"><span style="display:block;font-weight:bold;font-size:13px;">Address</span> Khudiram Pally, Malbazar, West Bengal, India, 735221</p>
//           <p style="margin:0 0 10px 0;padding:0;font-size:14px;"><span style="display:block;font-weight:bold;font-size:13px;">Number of gusets</span> 2</p>
//           <p style="margin:0 0 10px 0;padding:0;font-size:14px;"><span style="display:block;font-weight:bold;font-size:13px;">Duration of your vacation</span> 25/04/2017 to 28/04/2017 (3 Days)</p>
//         </td>
//       </tr>
//       <tr>
//         <td colspan="2" style="font-size:20px;padding:30px 15px 0 15px;">Items</td>
//       </tr>
//       <tr>
//         <td colspan="2" style="padding:15px;">
//           <p style="font-size:14px;margin:0;padding:10px;border:solid 1px #ddd;font-weight:bold;">
//             <span style="display:block;font-size:13px;font-weight:normal;">Homestay with fooding & lodging</span> Rs. 3500 <b style="font-size:12px;font-weight:300;"> /person/day</b>
//           </p>
//           <p style="font-size:14px;margin:0;padding:10px;border:solid 1px #ddd;font-weight:bold;"><span style="display:block;font-size:13px;font-weight:normal;">Pickup & Drop</span> Rs. 2000 <b style="font-size:12px;font-weight:300;"> /person/day</b></p>
//           <p style="font-size:14px;margin:0;padding:10px;border:solid 1px #ddd;font-weight:bold;"><span style="display:block;font-size:13px;font-weight:normal;">Local site seeing with guide</span> Rs. 800 <b style="font-size:12px;font-weight:300;"> /person/day</b></p>
//           <p style="font-size:14px;margin:0;padding:10px;border:solid 1px #ddd;font-weight:bold;"><span style="display:block;font-size:13px;font-weight:normal;">Tea tourism with guide</span> Rs. 500 <b style="font-size:12px;font-weight:300;"> /person/day</b></p>
//           <p style="font-size:14px;margin:0;padding:10px;border:solid 1px #ddd;font-weight:bold;"><span style="display:block;font-size:13px;font-weight:normal;">River side camping with guide</span> Rs. 1500 <b style="font-size:12px;font-weight:300;"> /person/day</b></p>
//           <p style="font-size:14px;margin:0;padding:10px;border:solid 1px #ddd;font-weight:bold;"><span style="display:block;font-size:13px;font-weight:normal;">Trackking and hiking with guide</span> Rs. 1000 <b style="font-size:12px;font-weight:300;"> /person/day</b></p>
//         </td>
//       </tr>
//     </tbody>
//     <tfooter>
//       <tr>
//         <td colspan="2" style="font-size:14px;padding:50px 15px 0 15px;">
//           <strong style="display:block;margin:0 0 10px 0;">Regards</strong> Bachana Tours<br> Gorubathan, Pin/Zip - 735221, Darjeeling, West bengal, India<br><br>
//           <b>Phone:</b> 03552-222011<br>
//           <b>Email:</b> contact@bachanatours.in
//         </td>
//       </tr>
//     </tfooter>
//   </table>
// </body>

// </html>';
// $headers = "From: praveen2005kumar@gmail.com";

// if (mail($to_email, $subject, $body, $headers)) {
//     echo "Email successfully sent to $to_email...";
// } else {
//     echo "Email sending failed...";
// }
//   }




    ?>
  </body>
</html>
