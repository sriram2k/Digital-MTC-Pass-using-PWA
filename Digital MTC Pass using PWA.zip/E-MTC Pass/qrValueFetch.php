<?php 
require_once('connection.php');
$busno =  $_GET['qrValue'];
session_start();
$usname=$_COOKIE['Name'];
$usphone=(String)$_COOKIE['Phone'];
$sql="SELECT * FROM users WHERE (Phone='$usphone' and Name = '$usname')";
$res=mysqli_query($conn,$sql);
$bus_route_no = array();
if (mysqli_num_rows($res) > 0) {
      while($row = mysqli_fetch_assoc($res))
    {
        $usrid = $row['mtcid'];
        $count = $row['Count'];
        $from = $row['From1'];
        $to = $row['To1'];
        $from2 = $row['From2'];
        $to2 = $row['To2'];
        $type = $row['Type'];   
         $img = $row['img'];
   
       } 
    
}
else {
    echo "invlaid";
    }

function clean($string)
{
    $string = str_replace(' ', '', $string);

    return preg_replace('/[^A-Za-z0-9\-]/', '', $string);
}
if ($type == 'college_one_way' || $type == 'college_two_way') {
    # code...

$sql2 = "SELECT * FROM routes WHERE bus_no = '$busno'";

    $res = mysqli_query($conn, $sql2);
    $name = "";
    if (mysqli_num_rows($res) > 0)
    {
        while ($row = mysqli_fetch_assoc($res))
        {
            $name = $row["bus_route"];
            $array = explode(",", $name);
            if ((in_array(clean($from), $array)) && (in_array(clean($to), $array)))
            {
            	
               header("Location:addcount.php");

            }
            else if(  (in_array(clean($from2), $array)) && (in_array(clean($to2), $array)) ){
            	
            	header("Location:addcount.php");

            }
            else{
                header("Location:dashboard.php?qrFetchError=invalid");
            }

        }

    }
}
else{
    $sql2 = "SELECT * FROM routes";
     $res = mysqli_query($conn, $sql2);
     while ($row = mysqli_fetch_assoc($res))
        {
           array_push($bus_route_no, $row['bus_no']);

        }
        if (in_array($busno, $bus_route_no)){
            header("Location:fromto.php?route=".$busno);
        }

    }


?>