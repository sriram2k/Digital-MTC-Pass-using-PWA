-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 08, 2021 at 03:50 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mtc`
--

-- --------------------------------------------------------

--
-- Table structure for table `routes`
--

CREATE TABLE `routes` (
  `id` int(11) NOT NULL,
  `bus_no` varchar(100) NOT NULL,
  `bus_route` varchar(10000) NOT NULL,
  `real_route` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `routes`
--

INSERT INTO `routes` (`id`, `bus_no`, `bus_route`, `real_route`) VALUES
(1, '70C', 'KOYMABEDUMARKET,KOYAMBEDUPS,MMDACOLONYRDJN,JNOFIIIAND1STAVE,JAFFARKHANPET,CIPET,STTHOMASMOUNTPO,MENAMABAKKAMOLDAIRPORT,THIRUSOOLAMNATIONALAIRP,PALLAVARAM,CHROMPET,TBSANATORIUM,TAMBARAM', 'KOYMABEDU MARKET, KOYAMBEDU P.S, M.M.D.A.COLONY RD.JN., JN OF III AND 1ST AVE, JAFFARKHAN PET, CIPET, ST THOMAS MOUNT PO, MENAMABAKKAM OLD AIRPORT, THIRUSOOLAM NATIONAL AIRP, PALLAVARAM, CHROMPET, T.B.SANATORIUM, TAMBARAM'),
(2, '62', 'REDHILLS,AAYURVEDAASHRAMAM,KAVANGARAI,SCREWFACTORY,SURAPEDU,KALLIKUPPAM,PUDUR,AMBOT,THIRUMULLAIVOAYL,POLYTECHNIC,AVADI', 'RED HILLS, AAYURVEDA ASHRAMAM, KAVANGARAI, SCREW FACTORY, SURAPEDU, KALLIKUPPAM, PUDUR, AMB OT, THIRUMULLAIVOAYL, POLYTECHNIC, AVADI'),
(3, 'S147C', 'AMBOT,DUNLOP,AMBATHURESTATE,MOGAIPAIRROADJN,THIRUMANGALAM,ANNANAGARCIRCLE,HOTELARUN,NUNGAMBAKKAMRS,STERLINGROAD,UTHAMARGANDHISALAICORP,VIDYODAYA,PONDYBAZAAR,TNAGAR', 'AMB OT, DUNLOP, AMBATHUR ESTATE, MOGAIPAIR ROAD JN., THIRUMANGALAM, ANNA NAGAR CIRCLE, HOTEL ARUN, NUNGAMBAKKAM R.S, STERLING ROAD, UTHAMAR GANDHISALAI (CORP, VIDYODAYA, PONDY BAZAAR, T.NAGAR'),
(4, 'M52ET', 'POZHICHALUR,PAMMAL,PALLAVARAM,CHROMPET,TBSANATORIUM,TAMBARAM,IRUMBULIYUR,PERUNGULATHUR,VANDALOOR,VANDALOORZOO,OORAPAKKAMSCHOOL,PALAKKACOMPANY,GUDUVANCHERY', 'POZHICHALUR, PAMMAL, PALLAVARAM, CHROMPET, T.B.SANATORIUM, TAMBARAM, IRUMBULIYUR, PERUNGULATHUR, VANDALOOR, VANDALOOR ZOO, OORAPAKKAM SCHOOL, PALAKKA COMPANY, GUDUVANCHERY'),
(5, '248ET', 'VNAGAR,P1POLICESTATION,DASAMAHAN,AYNAVARAM,KAMABARARANGAM,NATHAMUNITALKIES,LUCASTVS,AMBATHURESTATE,DUNLOP,AMBOT,ORAGADAMOT,ORAGADAM', 'V. NAGAR, P1.POLICE STATION, DASAMAHAN, AYNAVARAM, KAMABAR ARANGAM, NATHAMUNI TALKIES, LUCAS TVS, AMBATHUR ESTATE, DUNLOP, AMB OT, ORAGADAM O.T., ORAGADAM');

-- --------------------------------------------------------

--
-- Table structure for table `tn2021mtc_2`
--

CREATE TABLE `tn2021mtc_2` (
  `id` int(11) NOT NULL,
  `Date1` varchar(100) NOT NULL,
  `Time1` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tn2021mtc_2`
--

INSERT INTO `tn2021mtc_2` (`id`, `Date1`, `Time1`) VALUES
(1, '31st - 07 - 2021', '10:08 AM'),
(2, '31st - 07 - 2021', '10:08 AM');

-- --------------------------------------------------------

--
-- Table structure for table `tn2021mtc_93`
--

CREATE TABLE `tn2021mtc_93` (
  `id` int(11) NOT NULL,
  `Date1` varchar(100) NOT NULL,
  `Time1` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tn2021mtc_93`
--

INSERT INTO `tn2021mtc_93` (`id`, `Date1`, `Time1`) VALUES
(1, '8th - 08 - 2021', '06:54 PM'),
(2, '8th - 08 - 2021', '06:59 PM'),
(3, '08 - 08 - 2021', '07:14 PM');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `mtcid` varchar(200) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Expiry` text NOT NULL,
  `Phone` varchar(100) NOT NULL,
  `Fare` int(11) NOT NULL,
  `Due_Paid` varchar(20) NOT NULL,
  `Due_crossed` int(11) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Coll_Comp` varchar(100) NOT NULL,
  `img` varchar(1000) NOT NULL,
  `aadhaar` varchar(1000) NOT NULL,
  `proof` varchar(1000) NOT NULL,
  `Type` varchar(1000) NOT NULL,
  `Payment_his_time` longtext NOT NULL,
  `Payment_his_date` varchar(1000) NOT NULL,
  `From1` varchar(100) NOT NULL,
  `To1` varchar(100) NOT NULL,
  `From2` varchar(1000) NOT NULL,
  `To2` varchar(1000) NOT NULL,
  `Count` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `mtcid`, `Name`, `Expiry`, `Phone`, `Fare`, `Due_Paid`, `Due_crossed`, `Email`, `Coll_Comp`, `img`, `aadhaar`, `proof`, `Type`, `Payment_his_time`, `Payment_his_date`, `From1`, `To1`, `From2`, `To2`, `Count`) VALUES
(1, 'tn2021mtc_', 'Temp', '', '0000', 0, '', 0, '', '', '', '', '', '', '', '', 'Temp', 'Temp', '', '', 0),
(92, 'tn2021mtc_2', 'Divya Prakash', '11-12-2021', '9171831422', 260, 'Paid', 0, 'divyaprakash473@gmail.com', 'Velammal Engineering College', 'd7a86e23a3c41f0423f8783c30c42657-1627705693.jpg', 'eaadhaar_381491953661_16062021093956_611260-1627705693.pdf', 'c-1627705693.c', 'college_one_way', '09:58:13am,10:21:29am,10:24:11am', '2021-07-31,2021-07-31,2021-07-31', 'ANNA NAGAR CIRCLE', 'RED HILLS', '', '', 0),
(93, 'tn2021mtc_93', 'Sri', '11-09-2021', '1234', 340, 'Paid', 0, 'sri@vec', 'VEC', 'd7a86e23a3c41f0423f8783c30c42657-1628428978.jpg', '-1628428978.', '-1628428978.', 'college_two_way', '06:52:58pm', '2021-08-08', 'ANNA NAGAR CIRCLE', 'AMB OT', 'AMB OT', 'RED HILLS', 3);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `routes`
--
ALTER TABLE `routes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tn2021mtc_2`
--
ALTER TABLE `tn2021mtc_2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tn2021mtc_93`
--
ALTER TABLE `tn2021mtc_93`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `routes`
--
ALTER TABLE `routes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tn2021mtc_2`
--
ALTER TABLE `tn2021mtc_2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tn2021mtc_93`
--
ALTER TABLE `tn2021mtc_93`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=94;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
