<?php
require_once('connection.php');

date_default_timezone_set("Asia/Calcutta"); 


  
$urname=$_POST['name'];
$urphone=$_POST['phone'];
$urtype = $_POST['type'];
$urfrom=$_POST['from'];
$urto=$_POST['to'];
$urfrom2=$_POST['from2'];
$urto2=$_POST['to2'];
$email=$_POST['email'];
$wor_clg = $_POST['company'];
 

session_start();
$_SESSION['Name'] = $urname;
$_SESSION['Phone'] = $urphone;
$output_dir = "../propic/";
$RandomNum  = time();
$ImageName  = str_replace(' ','-',strtolower($_FILES['image']['name']));
$ImageType  = $_FILES['image']['type'];
$ImageExt = substr($ImageName, strrpos($ImageName, '.'));
$ImageExt   = str_replace('.','',$ImageExt);
$ImageName  = preg_replace("/\.[^.\s]{3,4}$/", "", $ImageName);
$NewImageName = $ImageName.'-'.$RandomNum.'.'.$ImageExt;
$ret[$NewImageName]= $output_dir.$NewImageName;
	
	
if (!file_exists($output_dir))
	{
		@mkdir($output_dir, 0777);
	}               
move_uploaded_file($_FILES["image"]["tmp_name"],$output_dir."/".$NewImageName );


$output_dir2 = "../aadhaar/";
$RandomNum2   = time();
$ImageName2      = str_replace(' ','-',strtolower($_FILES['aadhaar']['name']));
$ImageType2      = $_FILES['aadhaar']['type'];
$ImageExt2 = substr($ImageName2, strrpos($ImageName2, '.'));
$ImageExt2       = str_replace('.','',$ImageExt2);
$ImageName2      = preg_replace("/\.[^.\s]{3,4}$/", "", $ImageName2);
$NewImageName2 = $ImageName2.'-'.$RandomNum2.'.'.$ImageExt2;
$ret[$NewImageName2]= $output_dir2.$NewImageName2;
	
if (!file_exists($output_dir2))
	{
		@mkdir($output_dir2, 0777);
	}               
move_uploaded_file($_FILES["aadhaar"]["tmp_name"],$output_dir2."/".$NewImageName2 );



$output_dir3 = "../proof/";/* Path for file upload */
$RandomNum3   = time();
$ImageName3     = str_replace(' ','-',strtolower($_FILES['proof']['name'][0]));
$ImageType3      = $_FILES['proof']['type'];
$ImageExt3 = substr($ImageName3, strrpos($ImageName3, '.'));
$ImageExt3       = str_replace('.','',$ImageExt3);
$ImageName3     = preg_replace("/\.[^.\s]{3,4}$/", "", $ImageName3);
$NewImageName3 = $ImageName3.'-'.$RandomNum3.'.'.$ImageExt3;
$ret[$NewImageName3]= $output_dir3.$NewImageName3;
if (!file_exists($output_dir3))
	{
		@mkdir($output_dir3, 0777);
	}               
	move_uploaded_file($_FILES["proof"]["tmp_name"],$output_dir3."/".$NewImageName3 );
	 

$usrid="tn".date("Y")."mtc_";
$sql1="select * from users where id=(SELECT max(id) from users) ";
$result=mysqli_query($conn,$sql1);

if($result!=false){
$flag = 1;
while($row=mysqli_fetch_array($result)){
$tempid = $row["id"]; 
$usrid.=(string) ($row["id"]+1);
}
}

$sql1="select Phone from users";
$result=mysqli_query($conn,$sql1);

if($result!=false){

while($row=mysqli_fetch_array($result)){
$tmpph = $row["Phone"]; 
echo "$tmpph";
if($tmpph == $urphone){
  $flag = 0;
}
}
}
if($flag){

  if ($urtype == "college_one_way") {
    $month = date('m');
    $year = date('Y');
    $expmonth = $month+1;
    $expiry_reg = '11-'.sprintf("%02d", $expmonth).'-'.$year;
   $sql="INSERT INTO users(mtcid,Name,Expiry,Phone,Due_Paid,Email,Coll_Comp,img,aadhaar,proof,Type,From1,To1) VALUES('$usrid','$urname','$expiry_reg','$urphone','Paid','$email','$wor_clg','$NewImageName','$NewImageName2','$NewImageName3','college_one_way','$urfrom','$urto')";
$res=mysqli_query($conn,$sql);
}
elseif($urtype == "college_two_way")
{
   $month = date('m');
    $year = date('Y');
    $expmonth = $month+1;
    $expiry_reg = '11-'.sprintf("%02d", $expmonth).'-'.$year;
  
  $sql="INSERT INTO users(mtcid,Name,Expiry,Phone,Due_Paid,Email,Coll_Comp,img,aadhaar,proof,Type,From1,To1,From2,To2) VALUES('$usrid','$urname','$expiry_reg','$urphone','Paid','$email','$wor_clg','$NewImageName','$NewImageName2','$NewImageName3','college_two_way','$urfrom','$urto','$urfrom2','$urto2')";
$res=mysqli_query($conn,$sql);
}


$ntable="
CREATE TABLE `$usrid` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  
  `Date1` varchar(100) NOT NULL,
  `Time1` varchar(500) NOT NULL,
  PRIMARY KEY (id)
)";
      if(!mysqli_query($conn,$ntable)){
        die('Sorry for inconvineince'. mysqli_error($conn));
      }
      else{
       header("Location:fare.php");
        exit();
      }
}
   
else{
  echo "User exists";
}
        

?>