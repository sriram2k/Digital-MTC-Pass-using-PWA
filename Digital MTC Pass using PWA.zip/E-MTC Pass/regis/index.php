<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Registration</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
    <style media="screen">
      input:not([name="type"]){
        width:250px;
        border:1px solid black;
        border-radius: 5px;
        background-color: #f2f0f0;
        padding:2px;
      }
      label{
        font-weight:bold;
        font-size:16px;
        margin:10px 0px;
      }
    </style>
  </head>
  <body style="background-color: #4a90e2">
    <div class="container">
      <div class="row">
        <div class="col-md-1"></div>
        <div class="col-md-10" style="margin:20px 3px;">

          <div class="container bg-white" style="padding:50px;">
            <form class="registration_form" action="upload.php" method="post" enctype="multipart/form-data">
              <h2 style="color:#4a90e2;margin-bottom:50px;">MTC Pass Registration</h2>
              <div class="row">
                <div class="col-md-6">
                  <div class="form-row">
                      <div class="form-group">
                          <div class="form-input">
                          <label>    Full Name <span style="color:red">*</span></label><br /><input type="text" name="name" id="first_name"  class="required"/>
                          </div>

                          <div class="form-input">
                          <label>    Company / College Name <span style="color:red">*</span></label><br /><input type="text" name="company" id="company" />
                          </div>
                          <div class="form-input">
                          <label>    Email <span style="color:red">*</span></label><br /><input type="text" name="email" id="email" class="required"/>
                          </div>
                          <div class="form-input">
                          <label>    Phone number <span style="color:red">*</span></label><br /><input type="text" name="phone" id="phone_number"  class="required" />
                          </div>
                      </div>
                    </div>
                  </div>
                <div class="col-md-6">
                  <div class="form-group">
                      <div class="form-radio" id="radio-button">
                        <label>  Person Type <span style="color:red">*</span></label><br />
                          <div class="form-radio-group">
                              <div class="form-radio-item">
                                  <input type="radio" name="type" id="cash" value="college_one_way" class="required">
                                  College 1 Way
                                  <span class="check"></span>
                              </div>

                              <div class="form-radio-item">
                                  <input type="radio" name="type" id="demand"  value="college_two_way">
                                  College 2 Way
                                  <span class="check"></span>
                              </div>
                          </div>
                      </div>
                      <div class="form-input">
                        <label>  User picture</label><br /><input type="file"  name="image"  class = "required"/>
                      </div>
                      <div class="form-input">
                          <label>Aadhaar Card </label><br /><input type="file" name="aadhaar" class="required"/>
                      </div>
                      <div class="form-input">
                          <label>College / Company I'd </label><br /><input type="file" name="proof"  class="required" />
                      </div>

                    </div>
              </div>
          </div>
          <hr style="background-color: #329e5e"/>
          <div class="row">
            <div class="col-md-6">
              <div class="form-row" >
                <div class="form-group">
                   <label>Route 1</label>
                    <div class="form-input">
                      <label>From <span style="color:red">*</span></label><br />
                       <input list="fromRoutes" name="from" id="fromRoute">
                              <datalist id="fromRoutes">
                                 <select>
                                    <option value="KOYMABEDU MARKET"></option>
                                    <option value="KOYAMBEDU P.S"></option>
                                    <option value="M.M.D.A.COLONY RD.JN."></option>
                                    <option value="JN OF III AND 1ST AVE"></option>
                                    <option value="JAFFARKHAN PET"></option>
                                    <option value="CIPET"></option>
                                    <option value="ST THOMAS MOUNT PO"></option>
                                    <option value="MENAMABAKKAM OLD AIRPORT"></option>
                                    <option value="THIRUSOOLAM NATIONAL AIRP"></option>
                                    <option value="PALLAVARAM"></option>
                                    <option value="CHROMPET"></option>
                                    <option value="T.B.SANATORIUM"></option>
                                    <option value="TAMBARAM"></option>
                                    <option value="RED HILLS"></option>
                                    <option value="AAYURVEDA ASHRAMAM"></option>
                                    <option value="KAVANGARAI"></option>
                                    <option value="SCREW FACTORY"></option>
                                    <option value="SURAPEDU"></option>
                                    <option value="KALLIKUPPAM"></option>
                                    <option value="PUDUR"></option>
                                    <option value="AMB OT"></option>
                                    <option value="THIRUMULLAIVOAYL"></option>
                                    <option value="POLYTECHNIC"></option>
                                    <option value="AVADI"></option>
                                    <option value="AMB OT"></option>
                                    <option value="DUNLOP"></option>
                                    <option value="AMBATHUR ESTATE"></option>
                                    <option value="MOGAIPAIR ROAD JN."></option>
                                    <option value="THIRUMANGALAM"></option>
                                    <option value="ANNA NAGAR CIRCLE"></option>
                                    <option value="HOTEL ARUN"></option>
                                    <option value="NUNGAMBAKKAM R.S"></option>
                                    <option value="STERLING ROAD"></option>
                                    <option value="UTHAMAR GANDHISALAI (CORP"></option>
                                    <option value="VIDYODAYA"></option>
                                    <option value="PONDY BAZAAR"></option>
                                    <option value="T.NAGAR"></option>
                                    <option value="POZHICHALUR"></option>
                                    <option value="PAMMAL"></option>
                                    <option value="PALLAVARAM"></option>
                                    <option value="CHROMPET"></option>
                                    <option value="T.B.SANATORIUM"></option>
                                    <option value="TAMBARAM"></option>
                                    <option value="IRUMBULIYUR"></option>
                                    <option value="PERUNGULATHUR"></option>
                                    <option value="VANDALOOR"></option>
                                    <option value="VANDALOOR ZOO"></option>
                                    <option value="OORAPAKKAM SCHOOL"></option>
                                    <option value="PALAKKA COMPANY"></option>
                                    <option value="GUDUVANCHERY"></option>
                                    <option value="V. NAGAR"></option>
                                    <option value="P1.POLICE STATION"></option>
                                    <option value="DASAMAHAN"></option>
                                    <option value="AYNAVARAM"></option>
                                    <option value="KAMABAR ARANGAM"></option>
                                    <option value="NATHAMUNI TALKIES"></option>
                                    <option value="LUCAS TVS"></option>
                                    <option value="AMBATHUR ESTATE"></option>
                                    <option value="DUNLOP"></option>
                                    <option value="AMB OT"></option>
                                    <option value="ORAGADAM O.T."></option>
                                    <option value="ORAGADAM"></option>
                                    <option value="KOYMABEDU MARKET"></option>
                                    <option value="KOYAMBEDU P.S"></option>
                                    <option value="M.M.D.A.COLONY RD.JN."></option>
                                    <option value="JN OF III AND 1ST AVE"></option>
                                    <option value="JAFFARKHAN PET"></option>
                                    <option value="CIPET"></option>
                                    <option value="ST THOMAS MOUNT PO"></option>
                                    <option value="MENAMABAKKAM OLD AIRPORT"></option>
                                    <option value="THIRUSOOLAM NATIONAL AIRP"></option>
                                    <option value="PALLAVARAM"></option>
                                    <option value="CHROMPET"></option>
                                    <option value="T.B.SANATORIUM"></option>
                                    <option value="TAMBARAM"></option>
                                 </select>
                              </datalist>
                    </div>
                    <div class="form-input">
                      <label>To <span style="color:red">*</span></label><br />
                        <input list="fromRoutes" name="to" id="fromRoute">
                              <datalist id="fromRoutes">
                                 <select>
                                    <option value="KOYMABEDU MARKET"></option>
                                    <option value="KOYAMBEDU P.S"></option>
                                    <option value="M.M.D.A.COLONY RD.JN."></option>
                                    <option value="JN OF III AND 1ST AVE"></option>
                                    <option value="JAFFARKHAN PET"></option>
                                    <option value="CIPET"></option>
                                    <option value="ST THOMAS MOUNT PO"></option>
                                    <option value="MENAMABAKKAM OLD AIRPORT"></option>
                                    <option value="THIRUSOOLAM NATIONAL AIRP"></option>
                                    <option value="PALLAVARAM"></option>
                                    <option value="CHROMPET"></option>
                                    <option value="T.B.SANATORIUM"></option>
                                    <option value="TAMBARAM"></option>
                                    <option value="RED HILLS"></option>
                                    <option value="AAYURVEDA ASHRAMAM"></option>
                                    <option value="KAVANGARAI"></option>
                                    <option value="SCREW FACTORY"></option>
                                    <option value="SURAPEDU"></option>
                                    <option value="KALLIKUPPAM"></option>
                                    <option value="PUDUR"></option>
                                    <option value="AMB OT"></option>
                                    <option value="THIRUMULLAIVOAYL"></option>
                                    <option value="POLYTECHNIC"></option>
                                    <option value="AVADI"></option>
                                    <option value="AMB OT"></option>
                                    <option value="DUNLOP"></option>
                                    <option value="AMBATHUR ESTATE"></option>
                                    <option value="MOGAIPAIR ROAD JN."></option>
                                    <option value="THIRUMANGALAM"></option>
                                    <option value="ANNA NAGAR CIRCLE"></option>
                                    <option value="HOTEL ARUN"></option>
                                    <option value="NUNGAMBAKKAM R.S"></option>
                                    <option value="STERLING ROAD"></option>
                                    <option value="UTHAMAR GANDHISALAI (CORP"></option>
                                    <option value="VIDYODAYA"></option>
                                    <option value="PONDY BAZAAR"></option>
                                    <option value="T.NAGAR"></option>
                                    <option value="POZHICHALUR"></option>
                                    <option value="PAMMAL"></option>
                                    <option value="PALLAVARAM"></option>
                                    <option value="CHROMPET"></option>
                                    <option value="T.B.SANATORIUM"></option>
                                    <option value="TAMBARAM"></option>
                                    <option value="IRUMBULIYUR"></option>
                                    <option value="PERUNGULATHUR"></option>
                                    <option value="VANDALOOR"></option>
                                    <option value="VANDALOOR ZOO"></option>
                                    <option value="OORAPAKKAM SCHOOL"></option>
                                    <option value="PALAKKA COMPANY"></option>
                                    <option value="GUDUVANCHERY"></option>
                                    <option value="V. NAGAR"></option>
                                    <option value="P1.POLICE STATION"></option>
                                    <option value="DASAMAHAN"></option>
                                    <option value="AYNAVARAM"></option>
                                    <option value="KAMABAR ARANGAM"></option>
                                    <option value="NATHAMUNI TALKIES"></option>
                                    <option value="LUCAS TVS"></option>
                                    <option value="AMBATHUR ESTATE"></option>
                                    <option value="DUNLOP"></option>
                                    <option value="AMB OT"></option>
                                    <option value="ORAGADAM O.T."></option>
                                    <option value="ORAGADAM"></option>
                                    <option value="KOYMABEDU MARKET"></option>
                                    <option value="KOYAMBEDU P.S"></option>
                                    <option value="M.M.D.A.COLONY RD.JN."></option>
                                    <option value="JN OF III AND 1ST AVE"></option>
                                    <option value="JAFFARKHAN PET"></option>
                                    <option value="CIPET"></option>
                                    <option value="ST THOMAS MOUNT PO"></option>
                                    <option value="MENAMABAKKAM OLD AIRPORT"></option>
                                    <option value="THIRUSOOLAM NATIONAL AIRP"></option>
                                    <option value="PALLAVARAM"></option>
                                    <option value="CHROMPET"></option>
                                    <option value="T.B.SANATORIUM"></option>
                                    <option value="TAMBARAM"></option>
                                 </select>
                              </datalist>
                    </div>
                </div>
              </div><label>
            </div>
            <div class="col-md-6">
              <div class="form-group" >
                 <label>Route 2</label><br />
                  <div class="form-input">
                    <label>From </label><br />
                      <input list="fromRoutes" name="from2" id="fromRoute">
                              <datalist id="fromRoutes">
                                 <select>
                                    <option value="KOYMABEDU MARKET"></option>
                                    <option value="KOYAMBEDU P.S"></option>
                                    <option value="M.M.D.A.COLONY RD.JN."></option>
                                    <option value="JN OF III AND 1ST AVE"></option>
                                    <option value="JAFFARKHAN PET"></option>
                                    <option value="CIPET"></option>
                                    <option value="ST THOMAS MOUNT PO"></option>
                                    <option value="MENAMABAKKAM OLD AIRPORT"></option>
                                    <option value="THIRUSOOLAM NATIONAL AIRP"></option>
                                    <option value="PALLAVARAM"></option>
                                    <option value="CHROMPET"></option>
                                    <option value="T.B.SANATORIUM"></option>
                                    <option value="TAMBARAM"></option>
                                    <option value="RED HILLS"></option>
                                    <option value="AAYURVEDA ASHRAMAM"></option>
                                    <option value="KAVANGARAI"></option>
                                    <option value="SCREW FACTORY"></option>
                                    <option value="SURAPEDU"></option>
                                    <option value="KALLIKUPPAM"></option>
                                    <option value="PUDUR"></option>
                                    <option value="AMB OT"></option>
                                    <option value="THIRUMULLAIVOAYL"></option>
                                    <option value="POLYTECHNIC"></option>
                                    <option value="AVADI"></option>
                                    <option value="AMB OT"></option>
                                    <option value="DUNLOP"></option>
                                    <option value="AMBATHUR ESTATE"></option>
                                    <option value="MOGAIPAIR ROAD JN."></option>
                                    <option value="THIRUMANGALAM"></option>
                                    <option value="ANNA NAGAR CIRCLE"></option>
                                    <option value="HOTEL ARUN"></option>
                                    <option value="NUNGAMBAKKAM R.S"></option>
                                    <option value="STERLING ROAD"></option>
                                    <option value="UTHAMAR GANDHISALAI (CORP"></option>
                                    <option value="VIDYODAYA"></option>
                                    <option value="PONDY BAZAAR"></option>
                                    <option value="T.NAGAR"></option>
                                    <option value="POZHICHALUR"></option>
                                    <option value="PAMMAL"></option>
                                    <option value="PALLAVARAM"></option>
                                    <option value="CHROMPET"></option>
                                    <option value="T.B.SANATORIUM"></option>
                                    <option value="TAMBARAM"></option>
                                    <option value="IRUMBULIYUR"></option>
                                    <option value="PERUNGULATHUR"></option>
                                    <option value="VANDALOOR"></option>
                                    <option value="VANDALOOR ZOO"></option>
                                    <option value="OORAPAKKAM SCHOOL"></option>
                                    <option value="PALAKKA COMPANY"></option>
                                    <option value="GUDUVANCHERY"></option>
                                    <option value="V. NAGAR"></option>
                                    <option value="P1.POLICE STATION"></option>
                                    <option value="DASAMAHAN"></option>
                                    <option value="AYNAVARAM"></option>
                                    <option value="KAMABAR ARANGAM"></option>
                                    <option value="NATHAMUNI TALKIES"></option>
                                    <option value="LUCAS TVS"></option>
                                    <option value="AMBATHUR ESTATE"></option>
                                    <option value="DUNLOP"></option>
                                    <option value="AMB OT"></option>
                                    <option value="ORAGADAM O.T."></option>
                                    <option value="ORAGADAM"></option>
                                    <option value="KOYMABEDU MARKET"></option>
                                    <option value="KOYAMBEDU P.S"></option>
                                    <option value="M.M.D.A.COLONY RD.JN."></option>
                                    <option value="JN OF III AND 1ST AVE"></option>
                                    <option value="JAFFARKHAN PET"></option>
                                    <option value="CIPET"></option>
                                    <option value="ST THOMAS MOUNT PO"></option>
                                    <option value="MENAMABAKKAM OLD AIRPORT"></option>
                                    <option value="THIRUSOOLAM NATIONAL AIRP"></option>
                                    <option value="PALLAVARAM"></option>
                                    <option value="CHROMPET"></option>
                                    <option value="T.B.SANATORIUM"></option>
                                    <option value="TAMBARAM"></option>
                                 </select>
                              </datalist>
                  </div>
                  <div class="form-input">
                    <label>To </label><br />
                      <input list="fromRoutes" name="to2" id="fromRoute">
                              <datalist id="fromRoutes">
                                 <select>
                                    <option value="KOYMABEDU MARKET"></option>
                                    <option value="KOYAMBEDU P.S"></option>
                                    <option value="M.M.D.A.COLONY RD.JN."></option>
                                    <option value="JN OF III AND 1ST AVE"></option>
                                    <option value="JAFFARKHAN PET"></option>
                                    <option value="CIPET"></option>
                                    <option value="ST THOMAS MOUNT PO"></option>
                                    <option value="MENAMABAKKAM OLD AIRPORT"></option>
                                    <option value="THIRUSOOLAM NATIONAL AIRP"></option>
                                    <option value="PALLAVARAM"></option>
                                    <option value="CHROMPET"></option>
                                    <option value="T.B.SANATORIUM"></option>
                                    <option value="TAMBARAM"></option>
                                    <option value="RED HILLS"></option>
                                    <option value="AAYURVEDA ASHRAMAM"></option>
                                    <option value="KAVANGARAI"></option>
                                    <option value="SCREW FACTORY"></option>
                                    <option value="SURAPEDU"></option>
                                    <option value="KALLIKUPPAM"></option>
                                    <option value="PUDUR"></option>
                                    <option value="AMB OT"></option>
                                    <option value="THIRUMULLAIVOAYL"></option>
                                    <option value="POLYTECHNIC"></option>
                                    <option value="AVADI"></option>
                                    <option value="AMB OT"></option>
                                    <option value="DUNLOP"></option>
                                    <option value="AMBATHUR ESTATE"></option>
                                    <option value="MOGAIPAIR ROAD JN."></option>
                                    <option value="THIRUMANGALAM"></option>
                                    <option value="ANNA NAGAR CIRCLE"></option>
                                    <option value="HOTEL ARUN"></option>
                                    <option value="NUNGAMBAKKAM R.S"></option>
                                    <option value="STERLING ROAD"></option>
                                    <option value="UTHAMAR GANDHISALAI (CORP"></option>
                                    <option value="VIDYODAYA"></option>
                                    <option value="PONDY BAZAAR"></option>
                                    <option value="T.NAGAR"></option>
                                    <option value="POZHICHALUR"></option>
                                    <option value="PAMMAL"></option>
                                    <option value="PALLAVARAM"></option>
                                    <option value="CHROMPET"></option>
                                    <option value="T.B.SANATORIUM"></option>
                                    <option value="TAMBARAM"></option>
                                    <option value="IRUMBULIYUR"></option>
                                    <option value="PERUNGULATHUR"></option>
                                    <option value="VANDALOOR"></option>
                                    <option value="VANDALOOR ZOO"></option>
                                    <option value="OORAPAKKAM SCHOOL"></option>
                                    <option value="PALAKKA COMPANY"></option>
                                    <option value="GUDUVANCHERY"></option>
                                    <option value="V. NAGAR"></option>
                                    <option value="P1.POLICE STATION"></option>
                                    <option value="DASAMAHAN"></option>
                                    <option value="AYNAVARAM"></option>
                                    <option value="KAMABAR ARANGAM"></option>
                                    <option value="NATHAMUNI TALKIES"></option>
                                    <option value="LUCAS TVS"></option>
                                    <option value="AMBATHUR ESTATE"></option>
                                    <option value="DUNLOP"></option>
                                    <option value="AMB OT"></option>
                                    <option value="ORAGADAM O.T."></option>
                                    <option value="ORAGADAM"></option>
                                    <option value="KOYMABEDU MARKET"></option>
                                    <option value="KOYAMBEDU P.S"></option>
                                    <option value="M.M.D.A.COLONY RD.JN."></option>
                                    <option value="JN OF III AND 1ST AVE"></option>
                                    <option value="JAFFARKHAN PET"></option>
                                    <option value="CIPET"></option>
                                    <option value="ST THOMAS MOUNT PO"></option>
                                    <option value="MENAMABAKKAM OLD AIRPORT"></option>
                                    <option value="THIRUSOOLAM NATIONAL AIRP"></option>
                                    <option value="PALLAVARAM"></option>
                                    <option value="CHROMPET"></option>
                                    <option value="T.B.SANATORIUM"></option>
                                    <option value="TAMBARAM"></option>
                                 </select>
                              </datalist>
                  </div>
              </div>
            </div>
          </div>
          <div class="form-submit">
              <input type="submit" style="margin:10px 0px;border-radius:10px;background-color:green;color:white;border:1px solid green;padding:5px;" value="Submit" class="submit" id="submit" name="submit" />
              <br /><input type="reset" style="border-radius:10px;background-color:red;color:white;border:1px solid red;padding:5px;" value="Reset" class="submit" id="reset" name="reset" />
          </div>
        </div>
       </form>
      </div>
    </div>


  </body>
</html>
