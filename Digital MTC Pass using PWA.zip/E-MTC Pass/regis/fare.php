<?php
date_default_timezone_set("Asia/Calcutta"); 

include 'connection.php';
session_start();
error_reporting(0);
$usname = $_SESSION['Name'];
$usphone = (String)$_SESSION['Phone'];
$sql = "SELECT * FROM users WHERE Phone='$usphone' and Name = '$usname'";
$res = mysqli_query($conn, $sql);
if (mysqli_num_rows($res) > 0)
{
    while ($row = mysqli_fetch_assoc($res))
    {

        $usrid = $row['mtcid'];
        $urname = $row['Name'];
        $urphone = $row['Phone'];
        $type = $row['Type'];
        $from1 = $row['From1'];
        $from2 = $row['From2'];
        $to1 = $row['To1'];
        $to2 = $row['To2'];
        $email = $row['Email'];

    }

}

$fare = array(
    120.00,
    140.00,
    160.00,
    180.00,
    200.00,
    220.00,
    240.00,
    260.00,
    280.00,
    300.00,
    320.00,
    340.00
);


function clean($string)
{
    $string = str_replace(' ', '', $string);

    return preg_replace('/[^A-Za-z0-9\-]/', '', $string);
}

function stage_calc($from, $to)
{
    include 'connection.php';
    $max_stage_array = array();

    $sql = "SELECT * FROM routes";
    $res = mysqli_query($conn, $sql);
    $name = "";
    if (mysqli_num_rows($res) > 0)
    {
        while ($row = mysqli_fetch_assoc($res))
        {
            $name = $row["bus_route"];
            $array = explode(",", $name);
            if ((in_array($from, $array)) && (in_array($to, $array)))
            {
                $start_point_stage = array_search($from, $array);
                $end_point_stage = array_search($to, $array);
                $temp = abs($start_point_stage - $end_point_stage);

                array_push($max_stage_array, $temp);

            }

        }

    }
    $max_stage = max($max_stage_array);
    return ($max_stage + 1);
}

if ($type == 'college_one_way')
{
    $stage = stage_calc(clean($from1) , clean($to1));



}
else if ($type == 'college_two_way')
{
    $temp_stage1 = stage_calc(clean($from1) , clean($to1));
    $temp_stage2 = stage_calc(clean($from2) , clean($to2));
    $stage = $temp_stage1 + $temp_stage2;

}

if ($stage-1 >= 12) {
  $temp_far = 340;
        $sql1 = "UPDATE users SET Fare = '$temp_far' WHERE Phone='$usphone' and Name = '$usname'";
        mysqli_query($conn, $sql1);
}
else
{
  $temp_far = $fare[$stage - 1];
  $sql1 = "UPDATE users SET Fare = '$temp_far' WHERE Phone='$usphone' and Name = '$usname'";
        mysqli_query($conn, $sql1);
}
 



 $date = date("Y-m-d");
    $time = date("h:i:sa");
    if($pay_his_d == NULL)
    {
        $pay_his_d = $date;
        $sql1 = "UPDATE users SET Payment_his_date = '$pay_his_d' WHERE Phone='$usphone' and Name = '$usname'";
        //echo "$temp";
        mysqli_query($conn, $sql1);
    }
    else
    {
        //$name = $pay_his_d;
        $array = explode(",", $pay_his_d);
        array_push($array, $date);
        $temp = implode(',',$array);
        $sql1 = "UPDATE users SET Payment_his_date = '$temp' WHERE Phone='$usphone' and Name = '$usname'";
        //echo "$temp";
        mysqli_query($conn, $sql1);
    # code...
    }
    if($pay_his_t == NULL)
    {
        $pay_his_t = $time;
        $sql1 = "UPDATE users SET Payment_his_time= '$pay_his_t' WHERE Phone='$usphone' and Name = '$usname'";
        //echo "$temp";
        mysqli_query($conn, $sql1);
    }
    else
    {
        //$name = $pay_his_d;
        $array = explode(",", $pay_his_t);
        array_push($array, $time);
        $temp = implode(',',$array);
        $sql1 = "UPDATE users SET Payment_his_time = '$temp' WHERE Phone='$usphone' and Name = '$usname'";
        //echo "$temp";
        mysqli_query($conn, $sql1);
    # code...
    }
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Payment</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="payment.css">
  </head>
  <body>
    <div class="container py-5">
    <!-- For demo purpose -->
    <div class="row mb-4">
        <div class="col-lg-8 mx-auto text-center">
            <h1 class="display-6">Payment Gateway</h1>
        </div>
    </div> <!-- End -->
    <div class="row">
        <div class="col-lg-6 mx-auto ">
           <?php if ($stage-1 >= 12) { ?>
                            <h4 class="card-title">Fare: <?php echo '340'; ?></h4>
                          <?php } else{ ?>
                             <h4 class="card-title">Fare:<?php echo $fare[$stage - 1]; ?> </h4>
                          <?php } ?>
                          <p>To: MTC Bus Dept</p>
                          <p >Name: <?php echo $urname; ?></p>
                            <p >Phone: <?php echo $urphone; ?></p>
                            <p >Email:<?php echo $email; ?></p>
                            <p >Type: <?php echo $type; ?></p>
        </div>

        <div class="col-lg-6 mx-auto">
            <div class="card ">
                <div class="card-header">
                    <div class="bg-white shadow-sm pt-4 pl-2 pr-2 pb-2">
                        <!-- Credit card form tabs -->
                        <ul role="tablist" class="nav bg-light nav-pills rounded nav-fill mb-3">
                            <li class="nav-item"> <a data-toggle="pill" href="#credit-card" class="nav-link active "> <i class="fas fa-credit-card mr-2"></i> Credit Card </a> </li>
                            <li class="nav-item"> <a data-toggle="pill" href="#paypal" class="nav-link "> <i class="fab fa-paypal mr-2"></i> Paypal </a> </li>
                            <li class="nav-item"> <a data-toggle="pill" href="#net-banking" class="nav-link "> <i class="fas fa-mobile-alt mr-2"></i> Net Banking </a> </li>
                        </ul>
                    </div> <!-- End -->
                    <!-- Credit card form content -->
                    <div class="tab-content">
                        <!-- credit card info-->
                        <div id="credit-card" class="tab-pane fade show active pt-3">
                            <form role="form">
                                <div class="form-group"> <label for="username">
                                        <h6>Card Owner</h6>
                                    </label> <input type="text" name="username" placeholder="Card Owner Name" required class="form-control "> </div>
                                <div class="form-group"> <label for="cardNumber">
                                        <h6>Card number</h6>
                                    </label>
                                    <div class="input-group"> <input type="text" name="cardNumber" placeholder="Valid card number" class="form-control " required>
                                        <div class="input-group-append"> <span class="input-group-text text-muted"> <i class="fab fa-cc-visa mx-1"></i> <i class="fab fa-cc-mastercard mx-1"></i> <i class="fab fa-cc-amex mx-1"></i> </span> </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-8">
                                        <div class="form-group"> <label><span class="hidden-xs">
                                                    <h6>Expiration Date</h6>
                                                </span></label>
                                            <div class="input-group"> <input type="number" placeholder="MM" name="" class="form-control" required> <input type="number" placeholder="YY" name="" class="form-control" required> </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class="form-group mb-4"> <label data-toggle="tooltip" title="Three digit CV code on the back of your card">
                                                <h6>CVV <i class="fa fa-question-circle d-inline"></i></h6>
                                            </label> <input type="text" required class="form-control"> </div>
                                    </div>
                                </div>
                                <div class="card-footer"><a href="index.php"> <button type="button" class="subscribe btn btn-primary btn-block shadow-sm"> Confirm Payment </button></a>
                            </form>
                        </div>
                    </div> <!-- End -->
                    <!-- Paypal info -->
                    <div id="paypal" class="tab-pane fade pt-3">
                        <h6 class="pb-2">Select your paypal account type</h6>
                        <div class="form-group "> <label class="radio-inline"> <input type="radio" name="optradio" checked> Domestic </label> <label class="radio-inline"> <input type="radio" name="optradio" class="ml-5">International </label></div>
                        <p> <button type="button" class="btn btn-primary "><i class="fab fa-paypal mr-2"></i> Log into my Paypal</button> </p>
                        <p class="text-muted"> Note: After clicking on the button, you will be directed to a secure gateway for payment. After completing the payment process, you will be redirected back to the website to view details of your order. </p>
                    </div> <!-- End -->
                    <!-- bank transfer info -->
                    <div id="net-banking" class="tab-pane fade pt-3">
                        <div class="form-group "> <label for="Select Your Bank">
                                <h6>Select your Bank</h6>
                            </label> <select class="form-control" id="ccmonth">
                                <option value="" selected disabled>--Please select your Bank--</option>
                                <option>Bank 1</option>
                                <option>Bank 2</option>
                                <option>Bank 3</option>
                                <option>Bank 4</option>
                                <option>Bank 5</option>
                                <option>Bank 6</option>
                                <option>Bank 7</option>
                                <option>Bank 8</option>
                                <option>Bank 9</option>
                                <option>Bank 10</option>
                            </select> </div>
                        <div class="form-group">
                            <p> <button type="button" class="btn btn-primary "><i class="fas fa-mobile-alt mr-2"></i> Proceed Payment</button> </p>
                        </div>
                        <p class="text-muted">Note: After clicking on the button, you will be directed to a secure gateway for payment. After completing the payment process, you will be redirected back to the website to view details of your order. </p>
                    </div> <!-- End -->
                    <!-- End -->
                </div>
            </div>
        </div>
    </div>
  </body>
</html>
